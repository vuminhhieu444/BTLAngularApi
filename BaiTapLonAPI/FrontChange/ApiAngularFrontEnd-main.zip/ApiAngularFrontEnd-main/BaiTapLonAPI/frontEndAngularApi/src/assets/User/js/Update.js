$(".mega-menu-links li a").hover(function() {
    $(this).css('color', 'red');
}, function() {
    $(this).css('color', 'black');
});